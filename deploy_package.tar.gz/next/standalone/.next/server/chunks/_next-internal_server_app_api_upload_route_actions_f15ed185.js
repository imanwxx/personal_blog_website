module.exports=[23219,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upload_route_actions_f15ed185.js.map