module.exports=[21234,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_timeline_page_actions_e8df2d46.js.map