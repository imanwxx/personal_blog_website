module.exports=[79266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_essays_page_actions_1f034d3d.js.map