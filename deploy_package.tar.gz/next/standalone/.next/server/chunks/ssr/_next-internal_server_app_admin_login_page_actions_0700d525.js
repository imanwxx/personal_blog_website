module.exports=[92043,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_login_page_actions_0700d525.js.map