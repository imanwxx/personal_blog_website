module.exports=[11832,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tags_%5Btag%5D_page_actions_d0397da5.js.map