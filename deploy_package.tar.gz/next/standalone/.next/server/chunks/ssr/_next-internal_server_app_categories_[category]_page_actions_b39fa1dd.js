module.exports=[86973,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_categories_%5Bcategory%5D_page_actions_b39fa1dd.js.map