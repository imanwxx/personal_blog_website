module.exports=[3527,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_posts_%5Bslug%5D_page_actions_4168b916.js.map