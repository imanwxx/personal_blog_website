module.exports=[71268,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_categories_page_actions_3c6edf35.js.map