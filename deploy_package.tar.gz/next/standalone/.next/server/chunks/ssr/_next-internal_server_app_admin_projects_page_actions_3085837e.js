module.exports=[58513,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_projects_page_actions_3085837e.js.map