module.exports=[14226,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_posts_%5Bslug%5D_route_actions_d93757d1.js.map