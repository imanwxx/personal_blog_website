module.exports=[1695,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_about_route_actions_e8d3a6db.js.map