module.exports=[81474,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_comments_route_actions_e2402523.js.map