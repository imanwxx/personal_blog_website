module.exports=[621,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_projects_route_actions_38c611ee.js.map