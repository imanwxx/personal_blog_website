module.exports=[67306,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_search_route_actions_4244da48.js.map