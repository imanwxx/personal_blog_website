module.exports=[28058,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_views_route_actions_810a9aa1.js.map