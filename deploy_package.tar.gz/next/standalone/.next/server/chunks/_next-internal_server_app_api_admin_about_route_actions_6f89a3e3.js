module.exports=[78584,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_about_route_actions_6f89a3e3.js.map