var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/about/route.js")
R.c("server/chunks/[root-of-the-server]__96cef64b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_about_route_actions_6f89a3e3.js")
R.m(63534)
module.exports=R.m(63534).exports
