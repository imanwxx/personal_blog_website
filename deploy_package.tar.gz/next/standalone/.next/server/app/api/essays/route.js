var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/essays/route.js")
R.c("server/chunks/[externals]__8f555cee._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_8396a0e0.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__ef7e30e6._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_essays_route_actions_8e845581.js")
R.m(84821)
module.exports=R.m(84821).exports
