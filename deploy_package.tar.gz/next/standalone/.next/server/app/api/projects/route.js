var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/route.js")
R.c("server/chunks/[root-of-the-server]__6850fb6f._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__ef7e30e6._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_route_actions_38c611ee.js")
R.m(22321)
module.exports=R.m(22321).exports
