var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/views/route.js")
R.c("server/chunks/[root-of-the-server]__dc472a1f._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_views_route_actions_810a9aa1.js")
R.m(17842)
module.exports=R.m(17842).exports
