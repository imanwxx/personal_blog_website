var R=require("../../chunks/[turbopack]_runtime.js")("server/app/rss.xml/route.js")
R.c("server/chunks/[root-of-the-server]__82c23bd8._.js")
R.c("server/chunks/node_modules_57abbd42._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_rss_xml_route_actions_7e2fa38b.js")
R.m(65324)
module.exports=R.m(65324).exports
