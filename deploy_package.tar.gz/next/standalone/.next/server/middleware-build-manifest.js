globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/88e89063bacdf74d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/10cbf02e6fc36465.js",
    "static/chunks/e9db456e6febb5bf.js",
    "static/chunks/turbopack-23310885a584668b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];